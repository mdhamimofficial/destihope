import React, { useState, useMemo } from 'react';
import { 
  X, 
  Search, 
  SlidersHorizontal, 
  ChevronRight, 
  CheckCircle2, 
  Droplet, 
  Star, 
  BarChart2, 
  User, 
  Home, 
  MessageSquare, 
  PlaySquare, 
  Brain, 
  UserSearch, 
  ArrowLeftRight, 
  Settings, 
  Bell, 
  CreditCard, 
  Trash2, 
  HelpCircle, 
  LayoutGrid, 
  Phone, 
  RefreshCw, 
  Award, 
  Sparkles,
  Info,
  Check,
  Download
} from 'lucide-react';
import { ActiveModule, UserProfile, HubManualControls } from '../types';

interface SidebarDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectModule: (module: ActiveModule) => void;
  currentUser: UserProfile;
  isDarkMode?: boolean;
  onToggleDarkMode?: () => void;
  currentLang?: 'bn' | 'en';
  onToggleLanguage?: () => void;
  dataSaverEnabled?: boolean;
  onToggleDataSaver?: () => void;
  onOpenSettings?: () => void;
  onOpenNotifications?: () => void;
  onOpenBlueprint?: () => void;
  isOffline?: boolean;
  onToggleOfflineMode?: () => void;
  pendingSyncCount?: number;
  onTriggerSync?: () => void;
  activeModule?: ActiveModule;
  hubControls?: HubManualControls;
  onUpdateHubControl?: <K extends keyof HubManualControls>(key: K, value: HubManualControls[K]) => void;
  onResetHubControls?: () => void;
  onApplyMinimalPreset?: () => void;
}

// Stylized Desti Leaf Logo Icon matching UI design
export const DestiLeafIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5 text-white" }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className}>
    <path
      d="M19.8 4.2C17.2 2.2 13.4 1.8 10.2 3.2 6.4 4.8 3.5 8.7 3.2 12.8c-.2 3.2 1.2 6.3 3.6 8.3 1.2-2.8 3.5-5.5 6.6-7.3 3.7-2.1 7.2-2.7 8.8-2.8-.2-2.5-1.1-5-2.4-6.8z"
      fill="currentColor"
    />
    <path
      d="M4.5 19.5c1.7 1.8 4 2.8 6.5 2.8 4.8 0 8.9-3.2 10.1-7.7-1.8.2-5.4.9-9.1 3-2.9 1.6-4.9 3.7-5.9 5.3z"
      fill="currentColor"
      opacity="0.9"
    />
    <path
      d="M5.5 19.5C8 16 12 13 19 9.5"
      stroke="white"
      strokeWidth="1.8"
      strokeLinecap="round"
    />
  </svg>
);

export const SidebarDrawer: React.FC<SidebarDrawerProps> = ({
  isOpen,
  onClose,
  onSelectModule,
  currentUser,
  isDarkMode = false,
  onToggleDarkMode,
  currentLang = 'bn',
  onToggleLanguage,
  dataSaverEnabled = false,
  onToggleDataSaver,
  onOpenSettings,
  onOpenNotifications,
  onOpenBlueprint,
  isOffline = false,
  pendingSyncCount = 0,
  onTriggerSync,
  activeModule = 'hope',
  hubControls = {
    showLiveAlert: true,
    showQuickActions: true,
    showCategoryPills: true,
    compactFeedMode: false,
    autoPlayMedia: true,
    showModuleBadges: true,
    enableAnimations: true,
    hapticSoundFeedback: true,
    autoCloseOrbitTimer: true,
    dataSaver: false,
    highContrastMode: false,
  },
  onUpdateHubControl,
  onResetHubControls,
  onApplyMinimalPreset,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [storageUsed, setStorageUsed] = useState('52.8 MB');
  const [isClearingStorage, setIsClearingStorage] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  
  // Sub-modals for rich interactivity
  const [showManageModulesModal, setShowManageModulesModal] = useState(false);
  const [showPaymentsModal, setShowPaymentsModal] = useState(false);
  const [showHelpModal, setShowHelpModal] = useState(false);
  const [localDataSaver, setLocalDataSaver] = useState(dataSaverEnabled);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleClearCache = () => {
    if (storageUsed === '0.0 MB') {
      triggerToast('ক্যাশ মেমোরি ইতিমধ্যেই খালি আছে');
      return;
    }
    setIsClearingStorage(true);
    setTimeout(() => {
      setStorageUsed('0.0 MB');
      setIsClearingStorage(false);
      triggerToast('ক্যাশ মেমোরি সফলভাবে মুক্ত করা হয়েছে (৫২.৮ MB)');
    }, 600);
  };

  const handleToggleDataSaver = () => {
    const nextVal = !localDataSaver;
    setLocalDataSaver(nextVal);
    if (onToggleDataSaver) {
      onToggleDataSaver();
    }
    if (onUpdateHubControl) {
      onUpdateHubControl('dataSaver', nextVal);
    }
    triggerToast(`ডাটা সেভার মোড: ${nextVal ? 'চালু' : 'বন্ধ'}`);
  };

  // 6 Core Ecosystem Modules list with standardized styling
  const ecosystemModules = [
    {
      id: 'hope' as ActiveModule,
      name: 'DestiHope',
      subtitle: 'Community',
      icon: Home,
      iconBg: 'bg-rose-100 text-[#E53935]',
    },
    {
      id: 'care' as ActiveModule,
      name: 'DestiCare',
      subtitle: 'Health & Blood',
      icon: Droplet,
      iconBg: 'bg-rose-100 text-[#E53935]',
    },
    {
      id: 'chat' as ActiveModule,
      name: 'DestiChat',
      subtitle: 'Messaging',
      icon: MessageSquare,
      iconBg: 'bg-blue-100 text-blue-600',
    },
    {
      id: 'media' as ActiveModule,
      name: 'DestiMedia',
      subtitle: 'Video & Reels',
      icon: PlaySquare,
      iconBg: 'bg-purple-100 text-purple-600',
    },
    {
      id: 'brain' as ActiveModule,
      name: 'DestiBrain',
      subtitle: 'Learning & AI',
      icon: Brain,
      iconBg: 'bg-amber-100 text-amber-600',
    },
    {
      id: 'find' as ActiveModule,
      name: 'DestiFind',
      subtitle: 'People & Search',
      icon: UserSearch,
      iconBg: 'bg-emerald-100 text-emerald-600',
    }
  ];

  // Active module label
  const activeModuleLabel = useMemo(() => {
    const current = ecosystemModules.find((m) => m.id === activeModule);
    return current ? current.name : 'DestiHope';
  }, [activeModule]);

  // Fast cycle to next module
  const handleCycleNextModule = () => {
    const order: ActiveModule[] = ['hope', 'care', 'chat', 'media', 'brain', 'find'];
    const curIndex = order.indexOf(activeModule);
    const nextMod = order[(curIndex + 1) % order.length];
    onSelectModule(nextMod);
    triggerToast(`সুইচ করা হয়েছে: ${nextMod.toUpperCase()}`);
  };

  // Filter modules based on search query
  const filteredModules = useMemo(() => {
    if (!searchQuery.trim()) return ecosystemModules;
    const q = searchQuery.toLowerCase();
    return ecosystemModules.filter(
      (m) =>
        m.name.toLowerCase().includes(q) ||
        m.subtitle.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  // Filter settings items based on search query
  const myDestiItems = [
    {
      id: 'settings',
      title: 'Settings & Privacy',
      subtitle: 'Security, privacy & notifications',
      icon: Settings,
      iconBg: 'bg-slate-100 text-slate-700',
      action: () => {
        if (onOpenSettings) onOpenSettings();
        onClose();
      }
    },
    {
      id: 'notifications',
      title: 'Notifications',
      subtitle: 'Alerts & updates',
      icon: Bell,
      iconBg: 'bg-rose-50 text-rose-500',
      action: () => {
        if (onOpenNotifications) onOpenNotifications();
        onClose();
      }
    },
    {
      id: 'account',
      title: 'Account & Profile',
      subtitle: 'Personal info, preferences',
      icon: User,
      iconBg: 'bg-blue-50 text-blue-600',
      action: () => {
        onSelectModule('profile');
        onClose();
      }
    },
    {
      id: 'payments',
      title: 'Payments & Donation History',
      subtitle: 'Hope Points & donations',
      icon: CreditCard,
      iconBg: 'bg-amber-50 text-amber-600',
      action: () => setShowPaymentsModal(true)
    },
    {
      id: 'datasaver',
      title: 'Data Saver',
      subtitle: 'Use less data',
      icon: BarChart2,
      iconBg: 'bg-emerald-50 text-emerald-600',
      isToggle: true
    },
    {
      id: 'storage',
      title: 'Storage & Clear Space',
      subtitle: 'Free up space',
      icon: Trash2,
      iconBg: 'bg-slate-100 text-slate-600',
      hasValue: true,
      action: handleClearCache
    },
    {
      id: 'backup',
      title: 'Project Backup (ZIP)',
      subtitle: 'Download complete source code',
      icon: Download,
      iconBg: 'bg-indigo-50 text-indigo-600',
      hasValue: true,
      displayValue: '0.3 MB',
      action: () => {
        const link = document.createElement('a');
        link.href = '/destihope-backup.zip';
        link.download = 'destihope-project-backup.zip';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        triggerToast('প্রজেক্ট ব্যাকআপ ZIP ডাউনলোড শুরু হয়েছে!');
      }
    },
    {
      id: 'help',
      title: 'Help & Support',
      subtitle: 'Get help anytime',
      icon: HelpCircle,
      iconBg: 'bg-slate-100 text-slate-600',
      action: () => setShowHelpModal(true)
    }
  ];

  const filteredDestiItems = useMemo(() => {
    if (!searchQuery.trim()) return myDestiItems;
    const q = searchQuery.toLowerCase();
    return myDestiItems.filter(
      (item) =>
        item.title.toLowerCase().includes(q) ||
        item.subtitle.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Dimmed backdrop with smooth fade */}
      <div 
        onClick={onClose} 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity duration-200"
        aria-hidden="true"
      />

      {/* Drawer Canvas - Perfectly sized for mobile & desktop */}
      <div 
        className="relative w-full sm:w-[420px] max-w-[430px] h-full flex flex-col z-10 overflow-hidden shadow-2xl bg-white text-slate-900 transition-colors animate-in slide-in-from-left duration-250 select-none"
      >
        {/* TOP HEADER: DESTIHUB */}
        <div className="px-5 pt-4 pb-3 flex items-center justify-between shrink-0 bg-white border-b border-slate-100">
          <div className="flex items-center gap-3">
            {/* Red badge logo with white Desti leaf */}
            <div className="w-10 h-10 rounded-2xl bg-[#E53935] flex items-center justify-center text-white shadow-xs shrink-0">
              <DestiLeafIcon className="w-5.5 h-5.5 text-white" />
            </div>

            {/* Title & Subtitle */}
            <div>
              <div className="flex items-center">
                <span className="text-xl font-black tracking-tight text-slate-900">
                  DESTI<span className="text-[#E53935]">HUB</span>
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium">
                One Ecosystem. Endless Possibilities.
              </p>
            </div>
          </div>

          {/* Circular Close Button */}
          <button 
            onClick={onClose}
            aria-label="Close Desti Hub"
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 active:bg-slate-300 flex items-center justify-center text-slate-700 transition-colors cursor-pointer shrink-0"
          >
            <X className="w-5 h-5 stroke-[2.2]" />
          </button>
        </div>

        {/* SEARCH BAR */}
        <div className="px-5 py-2.5 shrink-0 bg-white">
          <div className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-3.5 py-2 flex items-center gap-2.5 shadow-2xs focus-within:border-slate-400 focus-within:bg-white transition-all">
            <Search className="w-4.5 h-4.5 text-slate-500 shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search anything... (e.g. blood, learning, people, media)"
              className="w-full bg-transparent text-xs sm:text-[13px] text-slate-800 placeholder-slate-400 outline-none font-medium"
            />
            {searchQuery ? (
              <button 
                onClick={() => setSearchQuery('')}
                className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
                title="Clear Search"
              >
                <X className="w-4 h-4" />
              </button>
            ) : (
              <button 
                onClick={() => setShowManageModulesModal(true)}
                title="Manage Modules & Settings"
                className="p-1 text-slate-600 hover:text-slate-900 cursor-pointer"
              >
                <SlidersHorizontal className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* TOAST BANNER */}
        {toastMessage && (
          <div className="bg-slate-900 text-white text-xs px-4 py-2 font-medium flex items-center justify-between shrink-0 animate-in fade-in duration-150">
            <span>{toastMessage}</span>
            <button onClick={() => setToastMessage(null)} className="p-0.5 opacity-70 hover:opacity-100">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* SCROLLABLE BODY CONTENT */}
        <div className="flex-1 overflow-y-auto px-5 py-2 space-y-4 overscroll-contain pb-8">
          
          {/* USER PROFILE CARD */}
          <div className="relative overflow-hidden rounded-3xl p-4 bg-gradient-to-r from-red-50/70 via-rose-50/50 to-pink-50/80 border border-rose-100/90 shadow-2xs space-y-3">
            {/* Top Right Decorative Script */}
            <div className="absolute right-3.5 top-3 pointer-events-none select-none z-10">
              <span className="font-['Caveat',cursive] text-slate-800 text-lg leading-tight rotate-[-6deg] tracking-wide font-bold block text-right">
                Together<br />We Create<br />Change
              </span>
            </div>

            {/* User Info Header */}
            <div 
              onClick={() => {
                onSelectModule('profile');
                onClose();
              }}
              className="flex items-start gap-3.5 pr-22 relative cursor-pointer group"
            >
              <div className="relative shrink-0">
                <img
                  src={currentUser.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80"}
                  alt={currentUser.name}
                  className="w-13 h-13 rounded-full object-cover ring-2 ring-white shadow-xs group-hover:scale-105 transition-transform"
                />
                {/* Active online green dot */}
                <span className="absolute bottom-0.5 right-0.5 w-3.5 h-3.5 bg-emerald-500 border-2 border-white rounded-full shadow-2xs" />
              </div>

              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5">
                  <h3 className="font-bold text-base text-slate-900 truncate group-hover:text-[#E53935] transition-colors">
                    {currentUser.name || 'Tanvir Ahmed'}
                  </h3>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
                </div>

                <p className="text-xs text-slate-500 font-medium">
                  @{currentUser.username || 'tanvir_ahmed'}
                </p>

                {/* Active Member Badge */}
                <div className="mt-1 inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-50 border border-emerald-200/90 text-emerald-700 text-[11px] font-semibold">
                  <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                  <span>Active Member</span>
                </div>
              </div>
            </div>

            {/* 3-Column Stats Bar */}
            <div className="grid grid-cols-3 divide-x divide-rose-200/70 pt-1">
              {/* Col 1: Blood Group */}
              <div 
                onClick={() => {
                  onSelectModule('care');
                  onClose();
                }}
                className="flex items-center gap-2 pl-0.5 pr-1.5 cursor-pointer hover:opacity-85 transition-opacity"
              >
                <div className="w-7 h-7 rounded-full bg-rose-100 flex items-center justify-center text-[#E53935] shrink-0">
                  <Droplet className="w-3.5 h-3.5 fill-[#E53935] text-[#E53935]" />
                </div>
                <div className="min-w-0">
                  <div className="font-bold text-sm text-slate-900 leading-tight">
                    {currentUser.bloodGroup || 'O+'}
                  </div>
                  <div className="text-[10px] text-slate-500 font-medium truncate">
                    Blood Group
                  </div>
                </div>
              </div>

              {/* Col 2: Hope Points */}
              <div 
                onClick={() => setShowPaymentsModal(true)}
                className="flex items-center gap-2 px-1.5 cursor-pointer hover:opacity-85 transition-opacity"
              >
                <div className="w-7 h-7 rounded-full bg-pink-100 flex items-center justify-center text-pink-600 shrink-0">
                  <Star className="w-3.5 h-3.5 fill-pink-500 text-pink-500" />
                </div>
                <div className="min-w-0">
                  <div className="font-bold text-sm text-slate-900 leading-tight">
                    {currentUser.hopePoints || 140}
                  </div>
                  <div className="text-[10px] text-slate-500 font-medium truncate">
                    Hope Points
                  </div>
                </div>
              </div>

              {/* Col 3: Contributions */}
              <div 
                onClick={() => {
                  onSelectModule('profile');
                  onClose();
                }}
                className="flex items-center gap-2 pl-2 cursor-pointer hover:opacity-85 transition-opacity"
              >
                <div className="w-7 h-7 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600 shrink-0">
                  <BarChart2 className="w-3.5 h-3.5 text-emerald-600" />
                </div>
                <div className="min-w-0">
                  <div className="font-bold text-sm text-slate-900 leading-tight">
                    12
                  </div>
                  <div className="text-[10px] text-slate-500 font-medium truncate">
                    Contributions
                  </div>
                </div>
              </div>
            </div>

            {/* View Your Profile Card Button */}
            <button
              onClick={() => {
                onSelectModule('profile');
                onClose();
              }}
              className="w-full bg-white/95 hover:bg-white active:scale-[0.99] border border-rose-100/90 rounded-2xl p-2.5 flex items-center justify-between shadow-2xs transition-all cursor-pointer group text-left"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-7.5 h-7.5 rounded-full bg-rose-50 flex items-center justify-center text-[#E53935] shrink-0 group-hover:scale-105 transition-transform">
                  <User className="w-4 h-4 text-[#E53935]" />
                </div>
                <div>
                  <div className="font-bold text-xs text-slate-900">
                    View Your Profile
                  </div>
                  <div className="text-[10px] text-slate-400 font-medium">
                    Activity • Badges • Impact • More
                  </div>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-slate-700 transition-colors" />
            </button>
          </div>

          {/* DESTI ECOSYSTEM SECTION */}
          <div className="space-y-2.5">
            {/* Header: Red vertical accent bar + Title & Subtitle + Manage Modules */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-5 bg-[#E53935] rounded-full shrink-0" />
                <div>
                  <h4 className="font-bold text-sm text-slate-900 leading-tight">
                    Desti Ecosystem
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    Switch between modules instantly
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowManageModulesModal(true)}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 active:bg-slate-100 text-slate-700 text-xs font-semibold cursor-pointer shadow-2xs transition-colors"
              >
                <LayoutGrid className="w-3.5 h-3.5 text-slate-600" />
                <span>Manage Modules</span>
                <ChevronRight className="w-3 h-3 text-slate-400" />
              </button>
            </div>

            {/* 3x2 Grid of Module Cards */}
            <div className="grid grid-cols-3 gap-2.5">
              {filteredModules.map((item) => {
                const Icon = item.icon;
                const isActive = activeModule === item.id;

                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onSelectModule(item.id);
                      onClose();
                    }}
                    className={`rounded-2xl p-2.5 text-left transition-all relative flex flex-col justify-between cursor-pointer min-h-[92px] active:scale-[0.97] ${
                      isActive
                        ? 'border-2 border-red-500 bg-white shadow-2xs ring-2 ring-red-100'
                        : 'border border-slate-200/90 hover:border-slate-300 bg-white hover:bg-slate-50/60 shadow-2xs'
                    }`}
                  >
                    {/* Top Row: Icon + Chevron */}
                    <div className="flex items-center justify-between w-full">
                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${item.iconBg}`}>
                        <Icon className="w-4.5 h-4.5" />
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                    </div>

                    {/* Middle: Title & Subtitle */}
                    <div className="mt-2 min-w-0">
                      <div className="font-bold text-xs text-slate-900 truncate">
                        {item.name}
                      </div>
                      <div className="text-[10px] text-slate-400 truncate font-medium">
                        {item.subtitle}
                      </div>
                    </div>

                    {/* Bottom: Active Pill if currently selected */}
                    {isActive && (
                      <div className="mt-1.5 flex justify-end">
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-rose-50 text-[#E53935] text-[9px] font-bold">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#E53935] animate-pulse" />
                          <span>Active</span>
                        </span>
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* CURRENTLY ON MODULE BANNER */}
          <div className="bg-gradient-to-r from-red-50/70 via-rose-50/50 to-pink-50/70 border border-rose-100 rounded-2xl p-3 flex items-center justify-between gap-2 shadow-2xs">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8.5 h-8.5 rounded-full bg-rose-100 flex items-center justify-center text-[#E53935] shrink-0">
                <ArrowLeftRight className="w-4 h-4 text-[#E53935]" />
              </div>
              <div className="min-w-0">
                <div className="text-xs text-slate-800 font-medium truncate">
                  Currently on <span className="font-bold text-[#E53935]">{activeModuleLabel}</span>
                </div>
                <div className="text-[11px] text-slate-400 truncate">
                  Switch to another module anytime
                </div>
              </div>
            </div>

            <button
              onClick={handleCycleNextModule}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#E53935] to-[#D32F2F] text-white text-xs font-bold flex items-center gap-1 shadow-2xs hover:opacity-95 active:scale-95 transition-all cursor-pointer shrink-0"
            >
              <ArrowLeftRight className="w-3.5 h-3.5" />
              <span>Switch Module</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* MY DESTI SECTION */}
          <div className="space-y-2.5">
            {/* Header: Red vertical accent bar + Title & Subtitle */}
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-5 bg-[#E53935] rounded-full shrink-0" />
              <div>
                <h4 className="font-bold text-sm text-slate-900 leading-tight">
                  My Desti
                </h4>
                <p className="text-[11px] text-slate-400">
                  Control, customize and manage your experience
                </p>
              </div>
            </div>

            {/* Clean List Items */}
            <div className="bg-white rounded-2xl border border-slate-100 divide-y divide-slate-100 overflow-hidden shadow-2xs">
              {filteredDestiItems.map((item) => {
                const ItemIcon = item.icon;

                if (item.isToggle) {
                  return (
                    <div key={item.id} className="p-3 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-8.5 h-8.5 rounded-full flex items-center justify-center shrink-0 ${item.iconBg}`}>
                          <ItemIcon className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="font-bold text-xs text-slate-900">
                            {item.title}
                          </div>
                          <div className="text-[11px] text-slate-400">
                            {item.subtitle}
                          </div>
                        </div>
                      </div>

                      {/* Toggle switch with tactile OFF/ON feedback */}
                      <button
                        type="button"
                        role="switch"
                        aria-checked={localDataSaver}
                        onClick={handleToggleDataSaver}
                        className={`w-14 h-7 rounded-full transition-colors flex items-center p-0.5 cursor-pointer font-bold text-[10px] select-none ${
                          localDataSaver 
                            ? 'bg-[#E53935] justify-end text-white' 
                            : 'bg-slate-300 justify-start text-slate-600'
                        }`}
                      >
                        {localDataSaver ? (
                          <span className="flex items-center gap-1 pr-1">
                            <span>ON</span>
                            <span className="w-5 h-5 rounded-full bg-white shadow-xs block" />
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 pl-1">
                            <span className="w-5 h-5 rounded-full bg-white shadow-xs block" />
                            <span>OFF</span>
                          </span>
                        )}
                      </button>
                    </div>
                  );
                }

                return (
                  <button
                    key={item.id}
                    onClick={item.action}
                    disabled={item.id === 'storage' && isClearingStorage}
                    className="w-full p-3 flex items-center justify-between hover:bg-slate-50/80 active:bg-slate-100/80 transition-colors text-left cursor-pointer group disabled:opacity-50"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-8.5 h-8.5 rounded-full flex items-center justify-center shrink-0 transition-colors ${item.iconBg}`}>
                        {item.id === 'storage' && isClearingStorage ? (
                          <RefreshCw className="w-4 h-4 animate-spin text-slate-600" />
                        ) : (
                          <ItemIcon className="w-4 h-4" />
                        )}
                      </div>
                      <div>
                        <div className="font-bold text-xs text-slate-900 group-hover:text-[#E53935] transition-colors">
                          {item.title}
                        </div>
                        <div className="text-[11px] text-slate-400 font-medium">
                          {item.subtitle}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      {item.hasValue && (
                        <span className="text-slate-600 text-xs font-semibold">
                          {item.displayValue || storageUsed}
                        </span>
                      )}
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-slate-600 transition-colors" />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* BOTTOM BANNER CARD */}
          <div className="relative overflow-hidden rounded-3xl p-3.5 bg-gradient-to-r from-red-50 via-rose-50 to-pink-100 border border-rose-200/60 shadow-2xs flex items-center justify-between">
            {/* Subtle Mountain Waves SVG in Background */}
            <div className="absolute right-0 bottom-0 pointer-events-none opacity-45">
              <svg width="240" height="70" viewBox="0 0 240 70" fill="none">
                <path d="M0 70L40 45L80 58L130 30L170 48L210 22L240 38V70H0Z" fill="url(#mountainGrad1)" opacity="0.6"/>
                <path d="M20 70L70 52L110 60L160 38L195 50L240 32V70H20Z" fill="url(#mountainGrad2)" opacity="0.8"/>
                <defs>
                  <linearGradient id="mountainGrad1" x1="0" y1="0" x2="240" y2="70" gradientUnits="userSpaceOnUse">
                    <stop stopColor="#F43F5E" />
                    <stop offset="1" stopColor="#A855F7" />
                  </linearGradient>
                  <linearGradient id="mountainGrad2" x1="0" y1="0" x2="240" y2="70" gradientUnits="userSpaceOnUse">
                    <stop stopColor="#FB7185" />
                    <stop offset="1" stopColor="#C084FC" />
                  </linearGradient>
                </defs>
              </svg>
            </div>

            {/* Left: DestiHub Logo & Subtitle */}
            <div className="flex items-center gap-3 relative z-10">
              <div className="w-10 h-10 rounded-2xl bg-[#E53935] flex items-center justify-center text-white shadow-xs shrink-0">
                <DestiLeafIcon className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="font-bold text-sm tracking-tight text-slate-900 leading-tight">
                  Desti<span className="text-[#E53935]">Hub</span>
                </div>
                <div className="text-[11px] text-slate-500 font-medium">
                  Powered by Desti Ecosystem
                </div>
              </div>
            </div>

            {/* Right: Stylized Cursive Script */}
            <div className="relative z-10 pr-2 pointer-events-none select-none">
              <span className="font-['Caveat',cursive] text-[#E53935] text-xl font-bold rotate-[-6deg] tracking-wide inline-block leading-tight text-right drop-shadow-2xs">
                Better<br />Together
              </span>
            </div>
          </div>

          {/* BOTTOM UTILITY FOOTER */}
          <div className="pt-1 pb-2 flex items-center justify-between text-xs text-slate-500 border-t border-slate-100">
            <button
              onClick={onToggleLanguage}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold cursor-pointer transition-colors"
            >
              <span>{currentLang === 'bn' ? 'বাংলা' : 'English'}</span>
            </button>

            <a
              href="tel:999"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-50 text-[#E53935] hover:bg-red-100 font-bold cursor-pointer transition-colors"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>জরুরি ৯৯৯</span>
            </a>

            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded-xl bg-slate-900 text-white font-semibold hover:bg-slate-800 transition-colors cursor-pointer"
            >
              বন্ধ করুন
            </button>
          </div>

        </div>
      </div>

      {/* SUB-MODAL 1: MANAGE MODULES */}
      {showManageModulesModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-sm w-full p-4.5 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-red-100 flex items-center justify-center text-[#E53935]">
                  <LayoutGrid className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">Manage Modules</h3>
                  <p className="text-[11px] text-slate-400">Configure visual elements & behavior</p>
                </div>
              </div>
              <button
                onClick={() => setShowManageModulesModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Presets */}
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  onResetHubControls?.();
                  triggerToast('ডিফল্ট ইন্টারফেস মোড সক্রিয়');
                }}
                className="p-2.5 rounded-xl border border-slate-200 hover:border-[#E53935] text-left cursor-pointer transition-colors"
              >
                <div className="text-xs font-bold text-slate-900">ডিফল্ট মোড</div>
                <div className="text-[10px] text-slate-400">সব স্ট্যান্ডার্ড এলিমেন্ট দৃশ্যমান</div>
              </button>

              <button
                onClick={() => {
                  onApplyMinimalPreset?.();
                  triggerToast('মিনিমালিস্ট মোড সক্রিয়');
                }}
                className="p-2.5 rounded-xl border border-slate-200 hover:border-[#E53935] text-left cursor-pointer transition-colors"
              >
                <div className="text-xs font-bold text-slate-900">মিনিমাল মোড</div>
                <div className="text-[10px] text-slate-400">অপ্রয়োজনীয় ব্যানার গোপন</div>
              </button>
            </div>

            {/* Toggles */}
            <div className="space-y-2 divide-y divide-slate-100 text-xs">
              <div className="pt-2 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-800">লাইভ অ্যালার্ট ব্যানার</div>
                  <div className="text-[11px] text-slate-400">জরুরি নোটিশ ব্যানার</div>
                </div>
                <button
                  role="switch"
                  aria-checked={hubControls.showLiveAlert}
                  onClick={() => onUpdateHubControl?.('showLiveAlert', !hubControls.showLiveAlert)}
                  className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                    hubControls.showLiveAlert ? 'bg-[#E53935]' : 'bg-slate-300'
                  }`}
                >
                  <span className={`block w-3.5 h-3.5 rounded-full bg-white transition-transform ${
                    hubControls.showLiveAlert ? 'translate-x-5' : 'translate-x-0.5'
                  }`} />
                </button>
              </div>

              <div className="pt-2 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-800">কুইক অ্যাকশন বাটন বার</div>
                  <div className="text-[11px] text-slate-400">রক্তদান ও সাহায্য চাওয়ার বাটন</div>
                </div>
                <button
                  role="switch"
                  aria-checked={hubControls.showQuickActions}
                  onClick={() => onUpdateHubControl?.('showQuickActions', !hubControls.showQuickActions)}
                  className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                    hubControls.showQuickActions ? 'bg-[#E53935]' : 'bg-slate-300'
                  }`}
                >
                  <span className={`block w-3.5 h-3.5 rounded-full bg-white transition-transform ${
                    hubControls.showQuickActions ? 'translate-x-5' : 'translate-x-0.5'
                  }`} />
                </button>
              </div>

              <div className="pt-2 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-800">ক্যাটাগরি ফিল্টার পিলস</div>
                  <div className="text-[11px] text-slate-400">রক্ত, নিখোঁজ ও সংবাদ ফিল্টার</div>
                </div>
                <button
                  role="switch"
                  aria-checked={hubControls.showCategoryPills}
                  onClick={() => onUpdateHubControl?.('showCategoryPills', !hubControls.showCategoryPills)}
                  className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                    hubControls.showCategoryPills ? 'bg-[#E53935]' : 'bg-slate-300'
                  }`}
                >
                  <span className={`block w-3.5 h-3.5 rounded-full bg-white transition-transform ${
                    hubControls.showCategoryPills ? 'translate-x-5' : 'translate-x-0.5'
                  }`} />
                </button>
              </div>

              <div className="pt-2 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-800">কমপ্যাক্ট ফিড লেআউট</div>
                  <div className="text-[11px] text-slate-400">কম ফাঁকা রেখে বেশি পোস্ট দেখা</div>
                </div>
                <button
                  role="switch"
                  aria-checked={hubControls.compactFeedMode}
                  onClick={() => onUpdateHubControl?.('compactFeedMode', !hubControls.compactFeedMode)}
                  className={`w-10 h-5 rounded-full transition-colors relative cursor-pointer ${
                    hubControls.compactFeedMode ? 'bg-[#E53935]' : 'bg-slate-300'
                  }`}
                >
                  <span className={`block w-3.5 h-3.5 rounded-full bg-white transition-transform ${
                    hubControls.compactFeedMode ? 'translate-x-5' : 'translate-x-0.5'
                  }`} />
                </button>
              </div>
            </div>

            <button
              onClick={() => setShowManageModulesModal(false)}
              className="w-full py-2.5 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 transition-colors cursor-pointer"
            >
              সম্পন্ন
            </button>
          </div>
        </div>
      )}

      {/* SUB-MODAL 2: PAYMENTS & DONATION HISTORY */}
      {showPaymentsModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-sm w-full p-4.5 shadow-2xl space-y-3.5 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-100 flex items-center justify-center text-amber-600">
                  <CreditCard className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">Payments & Hope Points</h3>
                  <p className="text-[11px] text-slate-400">Donations & volunteer impact</p>
                </div>
              </div>
              <button
                onClick={() => setShowPaymentsModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 rounded-2xl bg-amber-50/70 border border-amber-200/80 space-y-1">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-600">মোট Hope Points:</span>
                <span className="font-extrabold text-amber-700 text-sm">{currentUser.hopePoints || 140} HP</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-600">রক্তদান অবদান:</span>
                <span className="font-bold text-slate-800">৮ বার সফল দান</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-600">রেসকিউ সহায়তা:</span>
                <span className="font-bold text-slate-800">৩টি কেস সমাধান</span>
              </div>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed">
              DestiHope একটি অলাভজনক মানবকল্যাণ প্ল্যাটফর্ম। রক্তদান, নিখোঁজ তথ্য যাচাই ও শিক্ষামূলক সেবার মাধ্যমে সদস্যরা Hope Points ও ভলান্টিয়ার ব্যাজ অর্জন করেন।
            </p>

            <button
              onClick={() => setShowPaymentsModal(false)}
              className="w-full py-2.5 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 cursor-pointer"
            >
              ঠিক আছে
            </button>
          </div>
        </div>
      )}

      {/* SUB-MODAL 3: HELP & SUPPORT */}
      {showHelpModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-sm w-full p-4.5 shadow-2xl space-y-3.5 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-rose-100 flex items-center justify-center text-[#E53935]">
                  <HelpCircle className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">Help & Support</h3>
                  <p className="text-[11px] text-slate-400">২৪/৭ জরুরি সহায়তা ও নির্দেশিকা</p>
                </div>
              </div>
              <button
                onClick={() => setShowHelpModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <a
                href="tel:999"
                className="p-3 rounded-2xl bg-red-50 border border-red-200 flex items-center justify-between font-bold text-[#E53935] hover:bg-red-100 transition-colors"
              >
                <span className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  জাতীয় জরুরি সেবা (৯৯৯)
                </span>
                <span className="text-xs underline font-bold">কল করুন</span>
              </a>

              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-slate-700 space-y-1">
                <div className="font-bold text-slate-900">রক্তদানের সাধারণ নিয়মাবলি:</div>
                <p className="text-[11px] text-slate-500">• বয়স ১৮-৬০ বছর এবং ওজন অন্তত ৪৫ কেজি হতে হবে।</p>
                <p className="text-[11px] text-slate-500">• দুই রক্তদানের মধ্যে কমপক্ষে ৩-৪ মাসের বিরতি থাকতে হবে।</p>
              </div>

              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-slate-700 space-y-1">
                <div className="font-bold text-slate-900">নিখোঁজ ব্যক্তির তথ্য সংযোজন:</div>
                <p className="text-[11px] text-slate-500">• সঠিক জিডি নম্বর ও পরিবার বা অভিভাবকের যোগাযোগের নম্বর উল্লেখ বাধ্যতামূলক।</p>
              </div>
            </div>

            <button
              onClick={() => setShowHelpModal(false)}
              className="w-full py-2.5 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 cursor-pointer"
            >
              বন্ধ করুন
            </button>
          </div>
        </div>
      )}

    </div>
  );
};

export default SidebarDrawer;
