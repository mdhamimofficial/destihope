import React from 'react';
import { 
  Home, 
  Droplet, 
  MessageCircle, 
  MessageSquare,
  Users, 
  PlaySquare, 
  Building2, 
  Siren, 
  UserSearch, 
  CheckCircle2, 
  User, 
  Layers,
  Clapperboard,
  Radio,
  PlusCircle,
  HelpCircle,
  Award,
  Swords,
  Brain,
  ShieldCheck
} from 'lucide-react';
import { ActiveModule } from '../types';

// Custom SVG Icon matching user's exact 3-tier stacked layers module icon ("মডিউল")
export const ModuleLayersIcon: React.FC<{ 
  className?: string; 
  size?: number; 
  strokeWidth?: number;
  showDot?: boolean;
}> = ({
  className = "w-5.5 h-5.5",
  size = 22,
  strokeWidth = 2.2,
  showDot = false,
}) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    width={size}
    height={size}
    fill="none"
    stroke="currentColor"
    strokeWidth={strokeWidth}
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    {/* Top diamond layer */}
    <polygon points="12 2 2 7 12 12 22 7 12 2" />
    {/* Middle chevron layer */}
    <polyline points="2 12 12 17 22 12" />
    {/* Bottom chevron layer */}
    <polyline points="2 17 12 22 22 17" />
    {/* Satellite dot if requested */}
    {showDot && (
      <circle cx="21" cy="4" r="2" fill="currentColor" stroke="none" />
    )}
  </svg>
);

interface BottomNavProps {
  activeModule: ActiveModule;
  onSelectModule: (module: ActiveModule) => void;
  unreadChatCount?: number;
  onOpenModuleSwitcher?: () => void;
  activeSubTab?: string;
  onSelectSubTab?: (subTab: string) => void;
}

interface NavItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string; size?: number }>;
  isSwitcher?: boolean;
  badge?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeModule,
  onSelectModule,
  unreadChatCount = 2,
  onOpenModuleSwitcher,
  activeSubTab,
  onSelectSubTab,
}) => {
  // Define module-specific action tabs with clean labels
  const getNavItems = (): NavItem[] => {
    switch (activeModule) {
      case 'chat':
        return [
          { id: 'back_home', label: 'হোম', icon: Home },
          { id: 'chat', label: 'চ্যাট', icon: MessageSquare, badge: unreadChatCount > 0 ? unreadChatCount : undefined },
          { id: 'upload', label: 'নতুন', icon: PlusCircle },
          { id: 'module_switch', label: 'মডিউল', icon: ModuleLayersIcon },
          { id: 'community', label: 'গ্রুপ', icon: Users },
        ];
      case 'media':
        return [
          { id: 'back_home', label: 'হোম', icon: Home },
          { id: 'feed', label: 'ফিড', icon: PlaySquare },
          { id: 'reels', label: 'রিলস', icon: Clapperboard },
          { id: 'subscriptions', label: 'চ্যানেল', icon: Users },
          { id: 'chat', label: 'চ্যাট', icon: MessageCircle, badge: 2 },
          { id: 'profile', label: 'প্রোফাইল', icon: User },
        ];
      case 'brain':
        return [
          { id: 'back_home', label: 'হোম', icon: Home },
          { id: 'ai', label: 'এআই', icon: Brain },
          { id: 'learn', label: 'প্রশ্ন', icon: HelpCircle },
          { id: 'battle', label: 'কুইজ', icon: Award },
          { id: 'debate', label: 'ডিবেট', icon: Swords },
        ];
      case 'care':
        return [
          { id: 'back_home', label: 'হোম', icon: Home },
          { id: 'bloodbank', label: 'ডোনার', icon: Droplet },
          { id: 'hospitals', label: 'হাসপাতাল', icon: Building2 },
          { id: 'ambulance', label: 'অ্যাম্বুলেন্স', icon: Siren },
          { id: 'profile', label: 'প্রোফাইল', icon: User },
        ];
      case 'find':
        return [
          { id: 'back_home', label: 'হোম', icon: Home },
          { id: 'cases', label: 'নিখোঁজ', icon: UserSearch },
          { id: 'found', label: 'উদ্ধার', icon: CheckCircle2 },
          { id: 'radar', label: 'রাডার', icon: Radio },
          { id: 'profile', label: 'প্রোফাইল', icon: User },
        ];
      case 'profile':
        return [
          { id: 'back_home', label: 'হোম', icon: Home },
          { id: 'overview', label: 'পরিচিতি', icon: User },
          { id: 'modules', label: 'মডিউল', icon: Layers },
          { id: 'badges', label: 'পয়েন্ট', icon: Award },
          { id: 'security', label: 'নিরাপত্তা', icon: ShieldCheck },
        ];
      case 'hope':
      default:
        return [
          { id: 'hope', label: 'হোম', icon: Home },
          { id: 'chat', label: 'চ্যাট', icon: MessageCircle, badge: unreadChatCount > 0 ? unreadChatCount : undefined },
          { id: 'media', label: 'মিডিয়া', icon: Clapperboard },
          { id: 'brain', label: 'ব্রেন', icon: Brain },
          { id: 'care', label: 'কেয়ার', icon: Droplet },
          { id: 'find', label: 'নিখোঁজ', icon: UserSearch },
        ];
    }
  };

  const navItems = getNavItems();
  const isHome = activeModule === 'hope';

  // Active module theme color
  const getThemeColor = () => {
    switch (activeModule) {
      case 'chat': return 'text-teal-600';
      case 'media': return 'text-purple-600';
      case 'brain': return 'text-amber-600';
      case 'care': return 'text-rose-600';
      case 'find': return 'text-emerald-600';
      case 'profile': return 'text-slate-800';
      case 'hope':
      default:
        return 'text-[#E53935]';
    }
  };

  const activeColorClass = getThemeColor();

  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto backdrop-blur-lg border-t z-40 bg-white/95 border-gray-200/90 text-gray-800 shadow-[0_-2px_16px_rgba(0,0,0,0.06)] pb-safe select-none">
      <div className="flex items-center justify-around px-1 h-14 sm:h-15">
        {navItems.map((item) => {
          const isActive = isHome 
            ? item.id === 'hope' 
            : activeModule === 'chat'
            ? (activeSubTab === item.id || (item.id === 'chat' && (!activeSubTab || activeSubTab === 'chat' || activeSubTab === 'all')))
            : activeModule === 'media'
            ? (activeSubTab === item.id || ((item.id === 'feed' || item.id === 'home') && (!activeSubTab || activeSubTab === 'home' || activeSubTab === 'videos' || activeSubTab === 'feed')))
            : activeSubTab === item.id;
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              id={`nav-item-${item.id}`}
              onClick={() => {
                if (item.id === 'back_home') {
                  onSelectModule('hope');
                  return;
                }
                if (item.id === 'module_switch') {
                  if (onOpenModuleSwitcher) onOpenModuleSwitcher();
                  return;
                }
                if (isHome) {
                  if (item.id === 'hope') {
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  } else {
                    onSelectModule(item.id as ActiveModule);
                  }
                  return;
                }
                if (onSelectSubTab) {
                  onSelectSubTab(item.id);
                }
              }}
              className="flex-1 h-full flex flex-col items-center justify-center relative py-1 px-0.5 cursor-pointer active:scale-95 transition-all group"
              aria-label={item.label}
              title={item.id === 'back_home' ? 'হোম পেজে (Desti Hope) ফিরুন' : item.label}
            >
              {/* Standardized 22px-24px icon container */}
              <div className="relative flex items-center justify-center">
                <Icon
                  className={`w-5.5 h-5.5 transition-all duration-150 ${
                    isActive
                      ? `${activeColorClass} stroke-[2.3] scale-105`
                      : item.id === 'back_home'
                      ? 'text-gray-500 group-hover:text-[#E53935] stroke-[1.9]'
                      : 'text-gray-500 group-hover:text-gray-800 stroke-[1.9]'
                  }`}
                />

                {/* Compact, clean badge */}
                {item.badge && (
                  <span className="absolute -top-1.5 -right-2.5 min-w-[16px] h-4 bg-[#E53935] text-white text-[9px] font-black rounded-full px-1 flex items-center justify-center leading-none shadow-xs ring-2 ring-white">
                    {item.badge}
                  </span>
                )}
              </div>

              {/* Standard micro-label below icon for optimal mobile readability */}
              <span 
                className={`text-[10px] tracking-tight leading-none mt-1 truncate max-w-[56px] text-center transition-colors ${
                  isActive 
                    ? `font-bold ${activeColorClass}` 
                    : 'font-medium text-gray-500 group-hover:text-gray-700'
                }`}
              >
                {item.label}
              </span>

              {/* Active Indicator Dot under label */}
              {isActive && (
                <span
                  className={`absolute bottom-0.5 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full ${
                    activeColorClass.includes('teal')
                      ? 'bg-teal-600'
                      : activeColorClass.includes('purple')
                      ? 'bg-purple-600'
                      : activeColorClass.includes('amber')
                      ? 'bg-amber-600'
                      : activeColorClass.includes('rose')
                      ? 'bg-rose-600'
                      : activeColorClass.includes('emerald')
                      ? 'bg-emerald-600'
                      : 'bg-[#E53935]'
                  }`}
                />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
