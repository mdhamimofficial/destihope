import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Search, 
  SlidersHorizontal, 
  ChevronRight, 
  CheckCircle2, 
  Droplet, 
  Star, 
  BarChart3, 
  User, 
  Home, 
  MessageSquare, 
  PlaySquare, 
  Brain, 
  UserSearch, 
  ArrowLeftRight, 
  Settings, 
  Bell, 
  CreditCard, 
  Trash2, 
  HelpCircle, 
  LayoutGrid, 
  Sparkles 
} from 'lucide-react';
import { ActiveModule, UserProfile } from '../../types';
import { currentUser as defaultUser } from '../../data/mockData';

export interface RadialModuleItem {
  id: ActiveModule;
  label: string;
  nameBn: string;
  tagline: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
  borderLight: string;
  shadowColor: string;
}

export const HOME_MODULE_INFO: RadialModuleItem = {
  id: 'hope',
  label: 'হোম ফিড',
  nameBn: 'Desti Hope',
  tagline: 'জরুরি সেবা ও সামাজিক ফিড',
  icon: Home,
  color: '#E53935',
  bgColor: 'bg-red-500',
  borderLight: 'border-red-200',
  shadowColor: 'shadow-red-500/40'
};

export const ALL_ORBIT_MODULES: RadialModuleItem[] = [HOME_MODULE_INFO];

interface ModuleSwitcherModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectModule: (mod: ActiveModule) => void;
  activeModule: ActiveModule;
  currentUser?: UserProfile;
  dataSaverEnabled?: boolean;
  onToggleDataSaver?: () => void;
  onOpenSettings?: () => void;
  onOpenNotifications?: () => void;
  onShowHopePointsInfo?: () => void;
}

// 6 Core Modules definition precisely matching the DestiHub design
const DESTI_MODULES = [
  {
    id: 'hope' as ActiveModule,
    title: 'DestiHope',
    subtitle: 'Community',
    icon: Home,
    iconColor: 'text-[#E53935]',
    iconBg: 'bg-rose-100 dark:bg-rose-950/60',
  },
  {
    id: 'care' as ActiveModule,
    title: 'DestiCare',
    subtitle: 'Health & Blood',
    icon: Droplet,
    iconColor: 'text-red-500',
    iconBg: 'bg-red-100 dark:bg-red-950/60',
  },
  {
    id: 'chat' as ActiveModule,
    title: 'DestiChat',
    subtitle: 'Messaging',
    icon: MessageSquare,
    iconColor: 'text-blue-500',
    iconBg: 'bg-blue-100 dark:bg-blue-950/60',
  },
  {
    id: 'media' as ActiveModule,
    title: 'DestiMedia',
    subtitle: 'Video & Reels',
    icon: PlaySquare,
    iconColor: 'text-purple-600',
    iconBg: 'bg-purple-100 dark:bg-purple-950/60',
  },
  {
    id: 'brain' as ActiveModule,
    title: 'DestiBrain',
    subtitle: 'Learning & AI',
    icon: Brain,
    iconColor: 'text-amber-500',
    iconBg: 'bg-amber-100 dark:bg-amber-950/60',
  },
  {
    id: 'find' as ActiveModule,
    title: 'DestiFind',
    subtitle: 'People & Search',
    icon: UserSearch,
    iconColor: 'text-emerald-600',
    iconBg: 'bg-emerald-100 dark:bg-emerald-950/60',
  },
];

export const ModuleSwitcherModal: React.FC<ModuleSwitcherModalProps> = ({
  isOpen,
  onClose,
  onSelectModule,
  activeModule,
  currentUser = defaultUser,
  dataSaverEnabled = false,
  onToggleDataSaver,
  onOpenSettings,
  onOpenNotifications,
  onShowHopePointsInfo,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [storageSize, setStorageSize] = useState('52.8 MB');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleClearStorage = () => {
    setStorageSize('0.0 MB');
    showToast('স্টোরেজ ও ক্যাশ সফলভাবে খালি করা হয়েছে!');
  };

  // Active module lookup
  const currentModItem = DESTI_MODULES.find((m) => m.id === activeModule) || DESTI_MODULES[0];

  // Filter modules based on search query
  const filteredModules = DESTI_MODULES.filter((m) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      m.title.toLowerCase().includes(q) ||
      m.subtitle.toLowerCase().includes(q) ||
      m.id.toLowerCase().includes(q)
    );
  });

  return (
    <AnimatePresence>
      {isOpen && (
        <div 
          id="modal-destihub-hub"
          className="fixed inset-0 z-[120] flex items-end sm:items-center justify-center select-none overflow-hidden"
          onClick={onClose}
        >
          {/* Backdrop with frosted dark blur */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-xs cursor-pointer"
            onClick={onClose}
          />

          {/* Toast inside DestiHub */}
          {toastMessage && (
            <div className="fixed top-12 left-1/2 -translate-x-1/2 z-[130] bg-slate-900 text-white text-xs font-bold px-4 py-2 rounded-full shadow-2xl flex items-center space-x-2 border border-slate-700 animate-in fade-in slide-in-from-top-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>{toastMessage}</span>
            </div>
          )}

          {/* Main DestiHub Sheet Container */}
          <motion.div
            initial={{ y: '100%', opacity: 0.5 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: '100%', opacity: 0 }}
            transition={{ type: 'spring', damping: 28, stiffness: 350 }}
            className="relative z-10 bg-white dark:bg-slate-900 text-gray-900 dark:text-gray-100 w-full max-w-md max-h-[92vh] flex flex-col rounded-t-[32px] sm:rounded-[32px] shadow-[0_-10px_40px_rgba(0,0,0,0.25)] border-t sm:border border-gray-100 dark:border-slate-800 overflow-hidden cursor-default"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Top Sheet Drag Notch (Mobile) */}
            <div className="w-12 h-1.5 bg-gray-200 dark:bg-slate-700 rounded-full mx-auto mt-2.5 mb-1 shrink-0 sm:hidden" />

            {/* Scrollable Content */}
            <div className="flex-1 overflow-y-auto no-scrollbar px-4 sm:px-5 py-3 space-y-4">
              {/* ================= 1. DESTIHUB BRAND HEADER ================= */}
              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center space-x-2.5">
                  {/* Desti Red Leaf Emblem */}
                  <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-red-600 via-[#E53935] to-rose-500 flex items-center justify-center shadow-md shadow-red-500/30 shrink-0">
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                      className="w-5 h-5 text-white"
                    >
                      <path
                        d="M20 4.5C12.5 4.5 4.5 9.5 4.5 20C15 20 20 12 20 4.5Z"
                        fill="currentColor"
                      />
                      <path
                        d="M4.5 20C8 16 12 13 17 11.5"
                        stroke="#B71C1C"
                        strokeWidth="1.8"
                        strokeLinecap="round"
                      />
                    </svg>
                  </div>
                  <div>
                    <h1 className="text-xl font-black tracking-tight flex items-center">
                      <span className="text-gray-950 dark:text-white">DESTI</span>
                      <span className="text-[#E53935] ml-0.5">HUB</span>
                    </h1>
                    <p className="text-[11px] font-medium text-gray-400 dark:text-gray-400">
                      One Ecosystem. Endless Possibilities.
                    </p>
                  </div>
                </div>

                {/* Close Button */}
                <button
                  id="btn-destihub-close"
                  onClick={onClose}
                  className="w-9 h-9 rounded-full bg-gray-100 hover:bg-gray-200 dark:bg-slate-800 dark:hover:bg-slate-700 flex items-center justify-center text-gray-500 hover:text-gray-800 dark:text-gray-400 dark:hover:text-white transition-colors cursor-pointer"
                  aria-label="Close DestiHub"
                >
                  <X className="w-5 h-5 stroke-[2.2]" />
                </button>
              </div>

              {/* ================= 2. SEARCH BAR ================= */}
              <div className="relative flex items-center bg-gray-50/80 dark:bg-slate-800/80 border border-gray-200/90 dark:border-slate-700 rounded-full px-3.5 py-2 shadow-xs transition-all focus-within:border-red-400 focus-within:ring-2 focus-within:ring-red-100 dark:focus-within:ring-red-950">
                <Search className="w-4 h-4 text-gray-400 shrink-0" />
                <input
                  type="text"
                  placeholder="Search anything... (e.g. blood, learning, people, media)"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-transparent text-xs text-gray-800 dark:text-gray-100 placeholder:text-gray-400 pl-2 focus:outline-none font-medium"
                />
                {searchQuery ? (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-white cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                ) : (
                  <SlidersHorizontal className="w-4 h-4 text-gray-400 shrink-0 cursor-pointer" />
                )}
              </div>

              {/* ================= 3. USER PROFILE CARD ================= */}
              <div className="relative rounded-3xl p-4 bg-gradient-to-br from-rose-50/40 via-white to-pink-50/50 dark:from-slate-850 dark:via-slate-800 dark:to-slate-850 border border-pink-100/80 dark:border-slate-700/80 shadow-xs overflow-hidden">
                {/* Decorative Script Calligraphy in top right corner */}
                <div className="absolute top-2.5 right-3 text-right pointer-events-none select-none">
                  <span className="font-['Caveat',cursive] text-slate-800 dark:text-rose-400 text-lg font-bold leading-tight block rotate-[-6deg] tracking-wide">
                    Together<br />We Create<br />Change
                  </span>
                </div>

                {/* User Info Header */}
                <div 
                  onClick={() => {
                    onSelectModule('profile');
                    onClose();
                  }}
                  className="flex items-center space-x-3 cursor-pointer group"
                >
                  <div className="relative shrink-0">
                    <img
                      src={currentUser.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80'}
                      alt={currentUser.name}
                      referrerPolicy="no-referrer"
                      className="w-13 h-13 rounded-full object-cover ring-2 ring-white dark:ring-slate-700 shadow-sm group-hover:scale-105 transition-transform"
                    />
                    <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-white dark:border-slate-800 rounded-full" />
                  </div>

                  <div className="min-w-0 pr-16">
                    <div className="flex items-center space-x-1">
                      <h2 className="font-black text-base text-gray-900 dark:text-white truncate group-hover:text-red-600 transition-colors">
                        Tanvir Ahmed
                      </h2>
                      <ChevronRight className="w-4 h-4 text-gray-400 group-hover:translate-x-0.5 transition-transform shrink-0" />
                    </div>
                    <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">
                      @{currentUser.username || 'tanvir_ahmed'}
                    </p>
                    <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 mt-1 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200/80 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800/60">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600 fill-emerald-100 dark:fill-emerald-900" />
                      <span>Active Member</span>
                    </span>
                  </div>
                </div>

                {/* 3 Stats Row (Blood Group | Hope Points | Contributions) */}
                <div className="grid grid-cols-3 divide-x divide-gray-100 dark:divide-slate-700/80 my-3 py-2 border-y border-gray-100/90 dark:border-slate-700/70 text-center">
                  <div className="flex items-center justify-center space-x-2 px-1">
                    <div className="w-7 h-7 rounded-full bg-red-50 dark:bg-red-950/50 flex items-center justify-center text-red-500 shrink-0">
                      <Droplet className="w-3.5 h-3.5 fill-red-500" />
                    </div>
                    <div className="text-left">
                      <span className="text-sm font-black text-gray-900 dark:text-white block leading-tight">
                        {currentUser.bloodGroup || 'O+'}
                      </span>
                      <span className="text-[10px] text-gray-400 font-medium block">
                        Blood Group
                      </span>
                    </div>
                  </div>

                  <div 
                    onClick={() => {
                      if (onShowHopePointsInfo) onShowHopePointsInfo();
                      else showToast(`${currentUser.hopePoints} Hope Points সক্রিয়`);
                    }}
                    className="flex items-center justify-center space-x-2 px-1 cursor-pointer hover:opacity-80"
                  >
                    <div className="w-7 h-7 rounded-full bg-rose-50 dark:bg-rose-950/50 flex items-center justify-center text-rose-500 shrink-0">
                      <Star className="w-3.5 h-3.5 fill-rose-500" />
                    </div>
                    <div className="text-left">
                      <span className="text-sm font-black text-gray-900 dark:text-white block leading-tight">
                        {currentUser.hopePoints || 140}
                      </span>
                      <span className="text-[10px] text-gray-400 font-medium block">
                        Hope Points
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-center space-x-2 px-1">
                    <div className="w-7 h-7 rounded-full bg-teal-50 dark:bg-teal-950/50 flex items-center justify-center text-teal-600 shrink-0">
                      <BarChart3 className="w-3.5 h-3.5" />
                    </div>
                    <div className="text-left">
                      <span className="text-sm font-black text-gray-900 dark:text-white block leading-tight">
                        12
                      </span>
                      <span className="text-[10px] text-gray-400 font-medium block">
                        Contributions
                      </span>
                    </div>
                  </div>
                </div>

                {/* View Your Profile Action Banner */}
                <div
                  onClick={() => {
                    onSelectModule('profile');
                    onClose();
                  }}
                  className="bg-rose-100/60 hover:bg-rose-100 dark:bg-slate-700/50 dark:hover:bg-slate-700 p-2.5 rounded-2xl flex items-center justify-between cursor-pointer transition-colors group"
                >
                  <div className="flex items-center space-x-2.5">
                    <div className="w-7 h-7 rounded-full bg-[#E53935] text-white flex items-center justify-center shrink-0 shadow-xs">
                      <User className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-bold text-xs text-gray-900 dark:text-white leading-tight group-hover:text-red-600 transition-colors">
                        View Your Profile
                      </h4>
                      <p className="text-[10px] text-gray-500 dark:text-gray-400 font-medium">
                        Activity • Badges • Impact • More
                      </p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </div>

              {/* ================= 4. DESTI ECOSYSTEM SECTION ================= */}
              <div className="space-y-3 pt-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="w-1 h-5 bg-[#E53935] rounded-full" />
                    <div>
                      <h3 className="font-black text-sm sm:text-base text-gray-900 dark:text-white">
                        Desti Ecosystem
                      </h3>
                      <p className="text-[11px] text-gray-400 font-medium">
                        Switch between modules instantly
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => showToast('Desti Ecosystem মডিউলসমূহ সম্পূর্ণ সক্রিয়')}
                    className="flex items-center space-x-1.5 px-3 py-1.5 rounded-full border border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-[11px] font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-50 transition-colors shadow-2xs cursor-pointer"
                  >
                    <LayoutGrid className="w-3.5 h-3.5 text-gray-600 dark:text-gray-300" />
                    <span>Manage Modules</span>
                    <ChevronRight className="w-3 h-3 text-gray-400" />
                  </button>
                </div>

                {/* 6 Module Cards in 3x2 Grid */}
                <div className="grid grid-cols-3 gap-2.5">
                  {filteredModules.map((mod) => {
                    const isActive = mod.id === activeModule;
                    const Icon = mod.icon;
                    return (
                      <div
                        key={mod.id}
                        id={`destihub-card-${mod.id}`}
                        onClick={() => {
                          onSelectModule(mod.id);
                          onClose();
                        }}
                        className={`p-3 rounded-2xl transition-all cursor-pointer flex flex-col justify-between relative group ${
                          isActive
                            ? 'bg-rose-50/30 dark:bg-rose-950/20 border-2 border-[#E53935] shadow-sm shadow-red-500/10'
                            : 'bg-white dark:bg-slate-800/90 border border-gray-200/90 dark:border-slate-700/80 hover:border-gray-300 hover:shadow-xs'
                        }`}
                      >
                        {/* Top: Icon & Chevron */}
                        <div className="flex items-start justify-between mb-2">
                          <div
                            className={`w-9 h-9 rounded-2xl flex items-center justify-center shrink-0 ${mod.iconBg}`}
                          >
                            <Icon className={`w-5 h-5 ${mod.iconColor}`} />
                          </div>
                          <ChevronRight
                            className={`w-3.5 h-3.5 mt-1 transition-transform group-hover:translate-x-0.5 ${
                              isActive ? 'text-[#E53935]' : 'text-gray-300 dark:text-slate-600'
                            }`}
                          />
                        </div>

                        {/* Title & Subtitle */}
                        <div>
                          <h4 className="font-black text-xs text-gray-900 dark:text-white leading-tight">
                            {mod.title}
                          </h4>
                          <p className="text-[10px] text-gray-500 dark:text-gray-400 font-medium truncate mt-0.5">
                            {mod.subtitle}
                          </p>
                        </div>

                        {/* Active Badge */}
                        {isActive && (
                          <div className="mt-2 pt-1 border-t border-red-100 dark:border-red-950/60 flex items-center justify-between">
                            <span className="inline-flex items-center space-x-1 text-[9px] font-black text-[#E53935]">
                              <span className="w-1.5 h-1.5 rounded-full bg-[#E53935] animate-pulse" />
                              <span>Active</span>
                            </span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Switch Module Banner */}
                <div className="bg-gradient-to-r from-rose-50/80 via-pink-50/70 to-rose-50/80 dark:from-slate-800 dark:to-slate-800/80 border border-rose-100 dark:border-slate-700 rounded-2xl p-3 flex items-center justify-between gap-3 shadow-2xs">
                  <div className="flex items-center space-x-2.5 min-w-0">
                    <div className="w-9 h-9 rounded-full bg-rose-100 dark:bg-rose-950 text-[#E53935] flex items-center justify-center shrink-0">
                      <ArrowLeftRight className="w-4 h-4 stroke-[2.5]" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-gray-900 dark:text-white truncate">
                        Currently on <strong className="text-[#E53935] font-black">{currentModItem.title}</strong>
                      </p>
                      <p className="text-[10.5px] text-gray-500 dark:text-gray-400 font-medium truncate">
                        Switch to another module anytime
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      // Switch to another module in sequence or prompt
                      const otherMods = DESTI_MODULES.filter((m) => m.id !== activeModule);
                      const next = otherMods[0];
                      if (next) {
                        onSelectModule(next.id);
                        onClose();
                      }
                    }}
                    className="px-3.5 py-2 bg-[#E53935] hover:bg-red-600 active:scale-95 text-white font-bold text-xs rounded-full flex items-center space-x-1.5 shrink-0 shadow-md shadow-red-500/20 transition-all cursor-pointer"
                  >
                    <ArrowLeftRight className="w-3.5 h-3.5 stroke-[2.5]" />
                    <span>Switch Module</span>
                    <ChevronRight className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* ================= 5. MY DESTI SECTION ================= */}
              <div className="space-y-3 pt-1">
                <div className="flex items-center space-x-2">
                  <span className="w-1 h-5 bg-[#E53935] rounded-full" />
                  <div>
                    <h3 className="font-black text-sm sm:text-base text-gray-900 dark:text-white">
                      My Desti
                    </h3>
                    <p className="text-[11px] text-gray-400 font-medium">
                      Control, customize and manage your experience
                    </p>
                  </div>
                </div>

                {/* Menu List Card */}
                <div className="bg-white dark:bg-slate-800/90 border border-gray-200/90 dark:border-slate-700/80 rounded-3xl overflow-hidden divide-y divide-gray-100 dark:divide-slate-700/60 shadow-xs">
                  {/* 1. Settings & Privacy */}
                  <div
                    onClick={() => {
                      if (onOpenSettings) onOpenSettings();
                      else showToast('সেটিংস ওপেন করা হচ্ছে...');
                    }}
                    className="p-3.5 hover:bg-gray-50 dark:hover:bg-slate-750 flex items-center justify-between cursor-pointer transition-colors group"
                  >
                    <div className="flex items-center space-x-3 min-w-0">
                      <div className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center shrink-0">
                        <Settings className="w-4 h-4 stroke-[2.2]" />
                      </div>
                      <div className="min-w-0">
                        <h4 className="text-xs font-bold text-gray-900 dark:text-white group-hover:text-red-600 transition-colors">
                          Settings & Privacy
                        </h4>
                        <p className="text-[10.5px] text-gray-400 font-medium truncate">
                          Security, privacy & notifications
                        </p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-300 group-hover:translate-x-0.5 transition-transform" />
                  </div>

                  {/* 2. Notifications */}
                  <div
                    onClick={() => {
                      if (onOpenNotifications) onOpenNotifications();
                      else showToast('নোটিফিকেশন ওপেন করা হচ্ছে...');
                    }}
                    className="p-3.5 hover:bg-gray-50 dark:hover:bg-slate-750 flex items-center justify-between cursor-pointer transition-colors group"
                  >
                    <div className="flex items-center space-x-3 min-w-0">
                      <div className="w-8 h-8 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-600 flex items-center justify-center shrink-0">
                        <Bell className="w-4 h-4 stroke-[2.2]" />
                      </div>
                      <div className="min-w-0">
                        <h4 className="text-xs font-bold text-gray-900 dark:text-white group-hover:text-red-600 transition-colors">
                          Notifications
                        </h4>
                        <p className="text-[10.5px] text-gray-400 font-medium truncate">
                          Alerts & updates
                        </p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-300 group-hover:translate-x-0.5 transition-transform" />
                  </div>

                  {/* 3. Account & Profile */}
                  <div
                    onClick={() => {
                      onSelectModule('profile');
                      onClose();
                    }}
                    className="p-3.5 hover:bg-gray-50 dark:hover:bg-slate-750 flex items-center justify-between cursor-pointer transition-colors group"
                  >
                    <div className="flex items-center space-x-3 min-w-0">
                      <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-950/60 text-blue-600 flex items-center justify-center shrink-0">
                        <User className="w-4 h-4 stroke-[2.2]" />
                      </div>
                      <div className="min-w-0">
                        <h4 className="text-xs font-bold text-gray-900 dark:text-white group-hover:text-red-600 transition-colors">
                          Account & Profile
                        </h4>
                        <p className="text-[10.5px] text-gray-400 font-medium truncate">
                          Personal info, preferences
                        </p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-300 group-hover:translate-x-0.5 transition-transform" />
                  </div>

                  {/* 4. Payments & Donation History */}
                  <div
                    onClick={() => {
                      if (onShowHopePointsInfo) onShowHopePointsInfo();
                      else showToast('হোপ পয়েন্ট ও ডোনেশন ইতিহাস সক্রিয়');
                    }}
                    className="p-3.5 hover:bg-gray-50 dark:hover:bg-slate-750 flex items-center justify-between cursor-pointer transition-colors group"
                  >
                    <div className="flex items-center space-x-3 min-w-0">
                      <div className="w-8 h-8 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-600 flex items-center justify-center shrink-0">
                        <CreditCard className="w-4 h-4 stroke-[2.2]" />
                      </div>
                      <div className="min-w-0">
                        <h4 className="text-xs font-bold text-gray-900 dark:text-white group-hover:text-red-600 transition-colors">
                          Payments & Donation History
                        </h4>
                        <p className="text-[10.5px] text-gray-400 font-medium truncate">
                          Hope Points & donations
                        </p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-300 group-hover:translate-x-0.5 transition-transform" />
                  </div>

                  {/* 5. Data Saver Toggle */}
                  <div className="p-3.5 flex items-center justify-between">
                    <div className="flex items-center space-x-3 min-w-0">
                      <div className="w-8 h-8 rounded-full bg-teal-100 dark:bg-teal-950/60 text-teal-600 flex items-center justify-center shrink-0">
                        <BarChart3 className="w-4 h-4 stroke-[2.2]" />
                      </div>
                      <div className="min-w-0">
                        <h4 className="text-xs font-bold text-gray-900 dark:text-white">
                          Data Saver
                        </h4>
                        <p className="text-[10.5px] text-gray-400 font-medium truncate">
                          Use less data
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        if (onToggleDataSaver) onToggleDataSaver();
                        else showToast(`ডাটা সেভার: ${!dataSaverEnabled ? 'চালু' : 'বন্ধ'}`);
                      }}
                      className={`w-12 h-6.5 rounded-full transition-colors relative cursor-pointer flex items-center px-1 shrink-0 ${
                        dataSaverEnabled ? 'bg-emerald-600' : 'bg-gray-300 dark:bg-slate-600'
                      }`}
                      aria-label="Toggle Data Saver"
                    >
                      <span
                        className={`w-4.5 h-4.5 bg-white rounded-full transition-transform shadow-xs flex items-center justify-center ${
                          dataSaverEnabled ? 'translate-x-5.5' : 'translate-x-0'
                        }`}
                      />
                      <span
                        className={`text-[8.5px] font-black uppercase text-white absolute ${
                          dataSaverEnabled ? 'left-1.5' : 'right-1.5'
                        }`}
                      >
                        {dataSaverEnabled ? 'ON' : 'OFF'}
                      </span>
                    </button>
                  </div>

                  {/* 6. Storage & Clear Space */}
                  <div
                    onClick={handleClearStorage}
                    className="p-3.5 hover:bg-gray-50 dark:hover:bg-slate-750 flex items-center justify-between cursor-pointer transition-colors group"
                  >
                    <div className="flex items-center space-x-3 min-w-0">
                      <div className="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 flex items-center justify-center shrink-0">
                        <Trash2 className="w-4 h-4 stroke-[2.2]" />
                      </div>
                      <div className="min-w-0">
                        <h4 className="text-xs font-bold text-gray-900 dark:text-white group-hover:text-red-600 transition-colors">
                          Storage & Clear Space
                        </h4>
                        <p className="text-[10.5px] text-gray-400 font-medium truncate">
                          Free up space
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-1 text-gray-500 font-mono text-xs">
                      <span>{storageSize}</span>
                      <ChevronRight className="w-4 h-4 text-gray-300" />
                    </div>
                  </div>

                  {/* 7. Help & Support */}
                  <div
                    onClick={() => showToast('DestiHelp সাপোর্ট সার্বক্ষণিক ২৪/৭ প্রস্তুত')}
                    className="p-3.5 hover:bg-gray-50 dark:hover:bg-slate-750 flex items-center justify-between cursor-pointer transition-colors group"
                  >
                    <div className="flex items-center space-x-3 min-w-0">
                      <div className="w-8 h-8 rounded-full bg-sky-100 dark:bg-sky-950/60 text-sky-600 flex items-center justify-center shrink-0">
                        <HelpCircle className="w-4 h-4 stroke-[2.2]" />
                      </div>
                      <div className="min-w-0">
                        <h4 className="text-xs font-bold text-gray-900 dark:text-white group-hover:text-red-600 transition-colors">
                          Help & Support
                        </h4>
                        <p className="text-[10.5px] text-gray-400 font-medium truncate">
                          Get help anytime
                        </p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-300 group-hover:translate-x-0.5 transition-transform" />
                  </div>
                </div>
              </div>

              {/* ================= 6. BOTTOM BANNER / FOOTER ================= */}
              <div className="relative rounded-2xl p-3.5 bg-gradient-to-r from-rose-50 via-pink-100/70 to-rose-100/90 dark:from-slate-800 dark:via-rose-950/30 dark:to-slate-800 border border-pink-200/80 dark:border-slate-700 overflow-hidden flex items-center justify-between">
                <div className="flex items-center space-x-2.5 z-10">
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-red-600 to-rose-500 flex items-center justify-center text-white shadow-xs shrink-0">
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                      className="w-4.5 h-4.5 text-white"
                    >
                      <path
                        d="M20 4.5C12.5 4.5 4.5 9.5 4.5 20C15 20 20 12 20 4.5Z"
                        fill="currentColor"
                      />
                      <path
                        d="M4.5 20C8 16 12 13 17 11.5"
                        stroke="#B71C1C"
                        strokeWidth="1.8"
                        strokeLinecap="round"
                      />
                    </svg>
                  </div>
                  <div>
                    <h5 className="font-black text-xs text-gray-900 dark:text-white leading-tight">
                      <span>Desti</span>
                      <span className="text-[#E53935]">Hub</span>
                    </h5>
                    <p className="text-[10px] text-gray-500 dark:text-gray-400 font-medium">
                      Powered by Desti Ecosystem
                    </p>
                  </div>
                </div>

                {/* Red Cursive 'Better Together' script in bottom right corner */}
                <div className="z-10 text-right pr-2 pointer-events-none select-none">
                  <span className="font-['Caveat',cursive] text-[#E53935] text-xl font-bold rotate-[-6deg] tracking-wide inline-block leading-tight text-right drop-shadow-2xs">
                    Better<br />Together
                  </span>
                </div>
              </div>

              <div className="h-2" />
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
