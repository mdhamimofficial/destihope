import React, { useState, useEffect } from 'react';
import { 
  Header 
} from './components/Header';
import { 
  QuickActionsBar 
} from './components/QuickActionsBar';
import { 
  LiveAlertBanner 
} from './components/LiveAlertBanner';
import { 
  CategoryPills 
} from './components/CategoryPills';
import { 
  HomeFeed 
} from './components/HomeFeed';
import { 
  BottomNav 
} from './components/BottomNav';
import { 
  SidebarDrawer 
} from './components/SidebarDrawer';

// Modals
import { HelpBloodModal } from './components/modals/HelpBloodModal';
import { MissingDetailsModal } from './components/modals/MissingDetailsModal';
import { CreatePostModal } from './components/modals/CreatePostModal';
import { EmergencyModal } from './components/modals/EmergencyModal';
import { ActiveTimersModal } from './components/modals/ActiveTimersModal';
import { ModuleSwitcherModal } from './components/modals/ModuleSwitcherModal';
import { NotificationModal } from './components/modals/NotificationModal';

// Dedicated Modules
import { DestiChatView } from './components/modules/DestiChatView';
import { DestiMediaView } from './components/modules/DestiMediaView';
import { DestiBrainView } from './components/modules/DestiBrainView';
import { DestiCareView } from './components/modules/DestiCareView';
import { DestiFindView } from './components/modules/DestiFindView';
import { DestiProfileView } from './components/modules/DestiProfileView';

import { 
  ActiveModule, 
  FeedCategory, 
  FeedPost, 
  UserProfile 
} from './types';
import { 
  initialFeedPosts, 
  currentUser as defaultUser 
} from './data/mockData';
import { Award, Check, Sparkles, X } from 'lucide-react';

export default function App() {
  const [activeModule, setActiveModule] = useState<ActiveModule>('hope');
  const [activeCategory, setActiveCategory] = useState<FeedCategory>('For You');
  const [feedPosts, setFeedPosts] = useState<FeedPost[]>(() => {
    const cached = localStorage.getItem('destihope_feed_data');
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch (e) {
        return initialFeedPosts;
      }
    }
    return initialFeedPosts;
  });
  const [currentUser, setCurrentUser] = useState<UserProfile>(defaultUser);
  const [language, setLanguage] = useState<'bn' | 'en'>('bn');
  const [dataSaverEnabled, setDataSaverEnabled] = useState(false);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  useEffect(() => {
    localStorage.setItem('destihope_feed_data', JSON.stringify(feedPosts));
  }, [feedPosts]);

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Modals state
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isCreatePostOpen, setIsCreatePostOpen] = useState(false);
  const [isHelpBloodOpen, setIsHelpBloodOpen] = useState(false);
  const [selectedBloodPost, setSelectedBloodPost] = useState<FeedPost | null>(null);
  const [isMissingDetailsOpen, setIsMissingDetailsOpen] = useState(false);
  const [selectedMissingPost, setSelectedMissingPost] = useState<FeedPost | null>(null);
  const [isEmergencyModalOpen, setIsEmergencyModalOpen] = useState(false);
  const [isActiveTimersModalOpen, setIsActiveTimersModalOpen] = useState(false);
  const [isModuleSwitcherOpen, setIsModuleSwitcherOpen] = useState(false);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [isHopePointsInfoOpen, setIsHopePointsInfoOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sub-tabs state for each module
  const [subTabs, setSubTabs] = useState<Record<string, string>>({
    hope: 'feed',
    chat: 'all',
    media: 'reels',
    brain: 'ai',
    care: 'bloodbank',
    find: 'cases',
    profile: 'overview'
  });

  const handleSelectSubTab = (subTab: string) => {
    setSubTabs(prev => ({ ...prev, [activeModule]: subTab }));
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  const addHopePoints = (pts: number, reason?: string) => {
    setCurrentUser((prev) => ({
      ...prev,
      hopePoints: prev.hopePoints + pts,
    }));
    showToast(`+${pts} Hope Points যোগ হয়েছে! 🎉`);
  };

  // Trigger blood help modal
  const handleOpenBloodHelp = (post: FeedPost) => {
    setSelectedBloodPost(post);
    setIsHelpBloodOpen(true);
  };

  // Confirm blood donation
  const handleConfirmBloodHelp = (post: FeedPost) => {
    addHopePoints(10);
  };

  // Trigger missing person details modal
  const handleOpenMissingDetails = (post: FeedPost) => {
    setSelectedMissingPost(post);
    setIsMissingDetailsOpen(true);
  };

  // Handle post creation
  const handleCreatePost = (newPost: FeedPost) => {
    setFeedPosts((prev) => [newPost, ...prev]);
    showToast('আপনার পোস্ট সফলভাবে প্রকাশিত হয়েছে!');
    addHopePoints(5);
  };

  // Direct phone call action
  const handleCall = (phone: string) => {
    window.open(`tel:${phone}`, '_self');
    showToast(`কল করা হচ্ছে: ${phone}`);
  };

  const handleShare = (post: FeedPost) => {
    if (navigator.share) {
      navigator.share({
        title: post.title || 'DestiHope Post',
        text: post.content,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(`${post.title || 'DestiHope'}\n${post.content}`);
      showToast('লিংক কপি করা হয়েছে! (+৫ HP)');
      addHopePoints(5);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex justify-center selection:bg-red-500 selection:text-white">
      {/* Mobile Frame Container (Max width matching mobile experience precisely) */}
      <main className="w-full max-w-md bg-white min-h-screen relative flex flex-col shadow-xl overflow-x-hidden">
        {/* Toast Notification Alert */}
        {toastMessage && (
          <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 bg-gray-900/95 backdrop-blur-xs text-white text-xs font-bold py-2 px-4 rounded-full shadow-2xl flex items-center space-x-2 border border-white/20 animate-in fade-in slide-in-from-top-4 duration-200">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>{toastMessage}</span>
          </div>
        )}


        {/* Main Content Area by Module */}
        <div className="flex-1 flex flex-col relative">
          {activeModule === 'hope' && (
            <div className="flex-1 flex flex-col h-full">
              <Header
                onOpenMenu={() => setIsSidebarOpen(true)}
                onOpenCreatePost={() => setIsCreatePostOpen(true)}
                onOpenNotifications={() => setIsNotificationOpen(true)}
                onSearchClick={() => {
                  setActiveModule('hope');
                  setActiveCategory('News');
                  showToast('খোঁজার জন্য ক্যাটাগরি ফিল্টার সক্রিয় হয়েছে');
                }}
                unreadNotificationsCount={1}
                isOffline={isOffline}
                activeModule={activeModule}
              />
              <div className="flex-1 overflow-y-auto no-scrollbar pb-20">
                <QuickActionsBar
                  onLocationClick={() => {
                    setActiveModule('care');
                    showToast('কাছাকাছি হাসপাতাল তালিকা খোলা হয়েছে');
                  }}
                  onEmergencyCallClick={() => setIsEmergencyModalOpen(true)}
                  onTimerClick={() => setIsActiveTimersModalOpen(true)}
                  onReportsClick={() => {
                    setIsHopePointsInfoOpen(true);
                  }}
                  onLanguageToggle={() => {
                    const nextLang = language === 'bn' ? 'en' : 'bn';
                    setLanguage(nextLang);
                    showToast(`ভাষা পরিবর্তিত হয়েছে: ${nextLang === 'bn' ? 'বাংলা' : 'English'}`);
                  }}
                  onModuleGridClick={() => setIsModuleSwitcherOpen(true)}
                  currentLanguage={language}
                />
                <LiveAlertBanner
                  onAlertClick={() => {
                    const livePost = feedPosts.find((p) => p.type === 'blood');
                    if (livePost) handleOpenBloodHelp(livePost);
                  }}
                />
                <CategoryPills
                  activeCategory={activeCategory}
                  onSelectCategory={(cat) => setActiveCategory(cat)}
                />
                <HomeFeed
                  posts={feedPosts}
                  onHelpBlood={handleOpenBloodHelp}
                  onViewMissingDetails={handleOpenMissingDetails}
                  onSharePost={handleShare}
                  onCallContact={handleCall}
                  onShowHopePointsInfo={() => setIsHopePointsInfoOpen(true)}
                  activeFilter={activeCategory}
                />
              </div>
            </div>
          )}

          {activeModule === 'chat' && (
            <DestiChatView
              onBackToHome={() => setActiveModule('hope')}
              onOpenModuleSwitcher={() => setIsModuleSwitcherOpen(true)}
              activeSubTab={subTabs['chat']}
              onSelectSubTab={handleSelectSubTab}
            />
          )}

          {activeModule === 'media' && (
            <DestiMediaView 
              onOpenModuleSwitcher={() => setIsModuleSwitcherOpen(true)}
              onOpenMenu={() => setIsSidebarOpen(true)}
              onOpenNotifications={() => setIsNotificationOpen(true)}
              onSearchClick={() => showToast('মিডিয়া মডিউলে সার্চ ফিচার আসছে')}
              onOpenCreatePost={() => setIsCreatePostOpen(true)}
              activeSubTab={subTabs['media']}
              onSelectSubTab={handleSelectSubTab}
            />
          )}

          {activeModule === 'brain' && (
            <DestiBrainView
              onEarnHopePoints={(pts) => addHopePoints(pts)}
              onOpenModuleSwitcher={() => setIsModuleSwitcherOpen(true)}
              onOpenMenu={() => setIsSidebarOpen(true)}
              onOpenNotifications={() => setIsNotificationOpen(true)}
              onSearchClick={() => showToast('ব্রেইন মডিউলে সার্চ ফিচার আসছে')}
              onOpenCreatePost={() => setIsCreatePostOpen(true)}
              activeSubTab={subTabs['brain']}
              onSelectSubTab={handleSelectSubTab}
            />
          )}

          {activeModule === 'care' && (
            <DestiCareView
              onOpenMenu={() => setIsSidebarOpen(true)}
              onOpenCreateBloodRequest={() => setIsCreatePostOpen(true)}
              onCallContact={handleCall}
              onOpenModuleSwitcher={() => setIsModuleSwitcherOpen(true)}
              onOpenNotifications={() => setIsNotificationOpen(true)}
              activeSubTab={subTabs['care']}
              onSelectSubTab={handleSelectSubTab}
              currentUser={currentUser}
              onUpdateUser={setCurrentUser}
            />
          )}

          {activeModule === 'find' && (
            <DestiFindView
              currentUser={currentUser}
              onUpdateUser={setCurrentUser}
              onOpenMenu={() => setIsSidebarOpen(true)}
              onOpenReportMissing={() => setIsCreatePostOpen(true)}
              onOpenNotifications={() => setIsNotificationOpen(true)}
              onSelectCase={(c) => {
                const p = feedPosts.find((item) => item.missingDetails?.caseId === c.caseId);
                if (p) handleOpenMissingDetails(p);
              }}
              onCallContact={handleCall}
              onOpenModuleSwitcher={() => setIsModuleSwitcherOpen(true)}
              activeSubTab={subTabs['find']}
              onSelectSubTab={handleSelectSubTab}
            />
          )}

          {activeModule === 'profile' && (
            <DestiProfileView
              user={currentUser}
              onUpdateUser={setCurrentUser}
              onNavigateModule={(mod) => setActiveModule(mod)}
              dataSaverEnabled={dataSaverEnabled}
              onToggleDataSaver={() => {
                setDataSaverEnabled(!dataSaverEnabled);
                showToast(`ডাটা সেভার মোড: ${!dataSaverEnabled ? 'চালু' : 'বন্ধ'}`);
              }}
              onShowHopePointsInfo={() => setIsHopePointsInfoOpen(true)}
              onBackToHome={() => setActiveModule('hope')}
              activeSubTab={subTabs['profile']}
              onSelectSubTab={handleSelectSubTab}
            />
          )}
        </div>

        {/* Unified Bottom Navigation for all modules */}
        <BottomNav
          activeModule={activeModule}
          onSelectModule={(mod) => {
            if (mod === activeModule) {
              window.scrollTo({ top: 0, behavior: 'smooth' });
            } else {
              setActiveModule(mod);
            }
          }}
          unreadChatCount={2}
          onOpenModuleSwitcher={() => setIsModuleSwitcherOpen((prev) => !prev)}
          activeSubTab={subTabs[activeModule]}
          onSelectSubTab={handleSelectSubTab}
        />

        {/* Navigation Sidebar Drawer */}
        <SidebarDrawer
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
          onSelectModule={(mod) => {
            setActiveModule(mod);
            setIsSidebarOpen(false);
          }}
          currentUser={currentUser}
          dataSaverEnabled={dataSaverEnabled}
          onToggleDataSaver={() => {
            setDataSaverEnabled(!dataSaverEnabled);
            showToast(`ডাটা সেভার মোড: ${!dataSaverEnabled ? 'চালু' : 'বন্ধ'}`);
          }}
        />

        {/* Modals */}
        <CreatePostModal
          isOpen={isCreatePostOpen}
          onClose={() => setIsCreatePostOpen(false)}
          onSubmitPost={handleCreatePost}
        />

        <HelpBloodModal
          post={selectedBloodPost}
          onClose={() => setIsHelpBloodOpen(false)}
          onConfirmDonate={handleConfirmBloodHelp}
        />

        <MissingDetailsModal
          post={selectedMissingPost}
          onClose={() => setIsMissingDetailsOpen(false)}
          onShare={handleShare}
          onSightingReported={() => {
            addHopePoints(10);
            showToast('দেখা যাওয়ার তথ্য গৃহীত হয়েছে! (+১০ HP)');
          }}
        />

        <EmergencyModal
          isOpen={isEmergencyModalOpen}
          onClose={() => setIsEmergencyModalOpen(false)}
          onCall={handleCall}
        />

        <ActiveTimersModal
          isOpen={isActiveTimersModalOpen}
          onClose={() => setIsActiveTimersModalOpen(false)}
          bloodPosts={feedPosts.filter((p) => p.type === 'blood')}
          onSelectPost={handleOpenBloodHelp}
        />

        <ModuleSwitcherModal
          isOpen={isModuleSwitcherOpen}
          onClose={() => setIsModuleSwitcherOpen(false)}
          onSelectModule={(mod) => setActiveModule(mod)}
          activeModule={activeModule}
        />

        <NotificationModal
          isOpen={isNotificationOpen}
          onClose={() => setIsNotificationOpen(false)}
          onOpenBloodCase={() => {
            const bp = feedPosts.find((p) => p.type === 'blood');
            if (bp) handleOpenBloodHelp(bp);
          }}
          onOpenMissingCase={() => {
            const mp = feedPosts.find((p) => p.type === 'missing');
            if (mp) handleOpenMissingDetails(mp);
          }}
        />

        {/* Hope Points Explanation Modal */}
        {isHopePointsInfoOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <div className="bg-white rounded-2xl max-w-sm w-full p-4 shadow-2xl space-y-3">
              <div className="flex items-center justify-between border-b border-gray-100 pb-2">
                <div className="flex items-center space-x-2">
                  <Award className="w-5 h-5 text-teal-600" />
                  <h3 className="font-bold text-sm text-gray-900">Hope Points কী?</h3>
                </div>
                <button
                  onClick={() => setIsHopePointsInfoOpen(false)}
                  className="p-1 text-gray-400 hover:text-gray-600 rounded-full"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <p className="text-xs text-gray-600 leading-relaxed">
                DestiHope প্ল্যাটফর্মে রক্তদান সহায়তা, নিখোঁজ ব্যক্তির সন্ধান তথ্য প্রদান, শিক্ষামূলক উত্তর ও গঠনমূলক কাজের জন্য সদস্যরা <strong>Hope Points</strong> অর্জন করেন।
              </p>

              <div className="bg-teal-50 rounded-xl p-3 border border-teal-100 space-y-1.5 text-xs text-teal-900">
                <div className="flex justify-between font-medium">
                  <span>🩸 রক্তদান সহায়তা</span>
                  <span className="font-bold text-teal-700">+১০ HP</span>
                </div>
                <div className="flex justify-between font-medium">
                  <span>🔍 নিখোঁজ তথ্য যাচাই</span>
                  <span className="font-bold text-teal-700">+১০ HP</span>
                </div>
                <div className="flex justify-between font-medium">
                  <span>💡 সঠিক উত্তর প্রদান</span>
                  <span className="font-bold text-teal-700">+৫ HP</span>
                </div>
                <div className="flex justify-between font-medium">
                  <span>📢 জরুরি কেস শেয়ার</span>
                  <span className="font-bold text-teal-700">+৫ HP</span>
                </div>
              </div>

              <div className="text-[11px] text-gray-400">
                * দ্রষ্টব্য: Hope Points কোনো বাণিজ্যিক মুদ্রা নয়; এটি সামাজিক বিশ্বাস ও ভলান্টিয়ার স্বীকৃতির প্রতীক।
              </div>

              <button
                onClick={() => setIsHopePointsInfoOpen(false)}
                className="w-full py-2 bg-gray-900 text-white rounded-xl text-xs font-bold"
              >
                বুঝেছি
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
