import React from 'react';
import { Menu, SquarePen, Search, Bell, WifiOff, MessageCirclePlus, UploadCloud, Droplet, UserSearch, Lightbulb } from 'lucide-react';
import { ActiveModule } from '../types';

interface HeaderProps {
  onOpenMenu: () => void;
  onOpenCreatePost: () => void;
  onOpenNotifications: () => void;
  onSearchClick: () => void;
  unreadNotificationsCount?: number;
  isOffline?: boolean;
  activeModule?: ActiveModule;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenMenu,
  onOpenCreatePost,
  onOpenNotifications,
  onSearchClick,
  unreadNotificationsCount = 1,
  isOffline = false,
  activeModule = 'hope' as ActiveModule,
}) => {
  const getSecondWord = (mod: ActiveModule) => {
    switch (mod) {
      case 'chat': return 'CHAT';
      case 'media': return 'MEDIA';
      case 'brain': return 'BRAIN';
      case 'care': return 'CARE';
      case 'find': return 'FIND';
      case 'profile': return 'PROFILE';
      case 'hope':
      default:
        return 'HOPE';
    }
  };

  const getComposerProps = (mod: ActiveModule) => {
    switch (mod) {
      case 'chat': return { text: 'নতুন চ্যাট...', icon: MessageCirclePlus };
      case 'media': return { text: 'ভিডিও আপলোড...', icon: UploadCloud };
      case 'brain': return { text: 'নতুন ডিবেট...', icon: Lightbulb };
      case 'care': return { text: 'রক্তের আবেদন...', icon: Droplet };
      case 'find': return { text: 'নিখোঁজ রিপোর্ট...', icon: UserSearch };
      case 'hope':
      default:
        return { text: 'আপনার মতামত...', icon: SquarePen };
    }
  };

  const composer = getComposerProps(activeModule);
  const ComposerIcon = composer.icon;

  return (
    <header className="bg-white border-b border-gray-100 sticky top-0 z-30">
      {/* Offline Indicator Banner */}
      {isOffline && (
        <div className="bg-amber-500 text-white text-[10px] font-bold py-1 px-3 flex items-center justify-center gap-1.5 w-full">
          <WifiOff className="w-3.5 h-3.5" />
          <span>অফলাইন মোড (ডেটা সেভ করা হচ্ছে)</span>
        </div>
      )}

      {/* Main Top Header */}
      <div className="flex items-center justify-between px-2 sm:px-3 py-1.5 sm:py-2 gap-1 sm:gap-2 w-full">
        {/* Left section: Hamburger Menu & Brand Logo */}
        <div className="flex items-center shrink-0">
          <button
            id="btn-hamburger-menu"
            onClick={onOpenMenu}
            className="w-10 h-10 -ml-1 flex items-center justify-center text-gray-800 hover:bg-gray-100 active:bg-gray-200 rounded-full transition-all active:scale-95"
            aria-label="Open navigation menu"
          >
            <Menu className="w-6 h-6 sm:w-7 sm:h-7 stroke-[2.5]" />
          </button>

          {/* Brand Logo */}
          <div className="flex items-center cursor-pointer select-none -ml-0.5">
            <span className="font-black text-base sm:text-lg tracking-tight text-gray-950">DESTI</span>
            <span className="font-black text-base sm:text-lg tracking-tight text-[#E53935] ml-0.5">
              {getSecondWord(activeModule)}
            </span>
          </div>
        </div>

        {/* Center: Post composer input pill (Only for Hope feed) */}
        {activeModule === 'hope' ? (
          <div
            id="input-create-post-trigger"
            onClick={onOpenCreatePost}
            className="flex-1 min-w-0 max-w-[140px] xs:max-w-[160px] sm:max-w-[200px] flex items-center justify-between bg-white border border-gray-200 rounded-full px-2.5 py-1.5 shadow-2xs cursor-pointer hover:border-gray-300 transition-colors mx-2"
          >
            <span className="text-[11px] sm:text-xs text-gray-500 font-bold truncate">
              {composer.text}
            </span>
            <div className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center shrink-0 ml-1">
               <ComposerIcon className="w-3.5 h-3.5 text-gray-700" />
            </div>
          </div>
        ) : (
          <div className="flex-1 min-w-0"></div>
        )}

        {/* Right section: Search and Notification Icons (large 44px touch targets, highly accessible) */}
        <div className="flex items-center space-x-0.5 sm:space-x-1 shrink-0">
          
          {/* Module-Specific Action Button (If not Hope) */}
          {activeModule !== 'hope' && activeModule !== 'profile' && (
             <button
               onClick={onOpenCreatePost}
               className="w-10 h-10 flex items-center justify-center text-gray-800 hover:bg-gray-100 active:bg-gray-200 rounded-full transition-all active:scale-90"
               aria-label="Add / Action"
             >
               <ComposerIcon className="w-6 h-6 sm:w-6 sm:h-6 stroke-[2.5]" />
             </button>
          )}

          {/* Search Button */}
          <button
            id="btn-header-search"
            onClick={onSearchClick}
            className="w-11 h-11 flex items-center justify-center text-gray-800 hover:bg-gray-100 active:bg-gray-200 rounded-full transition-all active:scale-90"
            aria-label="Search"
          >
            <Search className="w-6 h-6 sm:w-7 sm:h-7 stroke-[2.5]" />
          </button>

          {/* Notification Bell Button */}
          <button
            id="btn-header-notifications"
            onClick={onOpenNotifications}
            className="w-11 h-11 flex items-center justify-center text-gray-800 hover:bg-gray-100 active:bg-gray-200 rounded-full relative transition-all active:scale-90"
            aria-label="Notifications"
          >
            <Bell className="w-6 h-6 sm:w-7 sm:h-7 stroke-[2.5]" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute top-1.5 right-1.5 min-w-[18px] h-[18px] px-1 bg-[#E53935] text-white text-[10px] font-black rounded-full flex items-center justify-center border-2 border-white leading-none shadow-xs">
                {unreadNotificationsCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
