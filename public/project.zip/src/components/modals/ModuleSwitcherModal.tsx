import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Home, MessageCircle, Clapperboard, Brain, Droplet, UserSearch, User, Layers } from 'lucide-react';
import { ActiveModule } from '../../types';

interface ModuleSwitcherModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectModule: (mod: ActiveModule) => void;
  activeModule: ActiveModule;
}

export const ModuleSwitcherModal: React.FC<ModuleSwitcherModalProps> = ({
  isOpen,
  onClose,
  onSelectModule,
  activeModule,
}) => {
  const MODULES = [
    {
      id: 'hope' as ActiveModule,
      name: 'হোম',
      sub: 'রক্ত ও ক্রাইসিস',
      icon: Home,
      gradient: 'from-red-500 to-rose-600',
      activeRing: 'ring-red-400 shadow-red-500/50',
    },
    {
      id: 'chat' as ActiveModule,
      name: 'চ্যাট',
      sub: 'মেসেজ ও টিম',
      icon: MessageCircle,
      gradient: 'from-teal-500 to-emerald-600',
      activeRing: 'ring-teal-400 shadow-teal-500/50',
    },
    {
      id: 'media' as ActiveModule,
      name: 'মিডিয়া',
      sub: 'রিলস ও ভিডিও',
      icon: Clapperboard,
      gradient: 'from-purple-600 to-pink-600',
      activeRing: 'ring-purple-400 shadow-purple-500/50',
    },
    {
      id: 'brain' as ActiveModule,
      name: 'ব্রেন',
      sub: 'এআই ট্রায়াজ',
      icon: Brain,
      gradient: 'from-amber-500 to-orange-600',
      activeRing: 'ring-amber-400 shadow-amber-500/50',
    },
    {
      id: 'care' as ActiveModule,
      name: 'কেয়ার',
      sub: 'হাসপাতাল ও রক্ত',
      icon: Droplet,
      gradient: 'from-rose-500 to-red-600',
      activeRing: 'ring-rose-400 shadow-rose-500/50',
    },
    {
      id: 'find' as ActiveModule,
      name: 'নিখোঁজ',
      sub: 'সন্ধান ও উদ্ধার',
      icon: UserSearch,
      gradient: 'from-emerald-500 to-teal-600',
      activeRing: 'ring-emerald-400 shadow-emerald-500/50',
    },
    {
      id: 'profile' as ActiveModule,
      name: 'প্রোফাইল',
      sub: 'ডোনার প্রোফাইল',
      icon: User,
      gradient: 'from-slate-700 to-slate-900',
      activeRing: 'ring-slate-400 shadow-slate-500/50',
    },
  ];

  const total = MODULES.length;
  // Radius for the circular arrangement
  const radius = 124;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/50 backdrop-blur-xs px-4"
          onClick={onClose}
        >
          <div
            className="relative flex items-center justify-center w-full h-full max-w-md mx-auto select-none"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Circular Orbit Ring (Subtle decorative dashed guide) */}
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              transition={{ duration: 0.25 }}
              style={{ width: radius * 2 + 10, height: radius * 2 + 10 }}
              className="absolute rounded-full border border-white/20 pointer-events-none"
            />

            {/* Center Hub: Animated Module Icon with Close Action */}
            <motion.button
              initial={{ scale: 0, rotate: -45, opacity: 0 }}
              animate={{ scale: 1, rotate: 0, opacity: 1 }}
              exit={{ scale: 0, rotate: 45, opacity: 0 }}
              transition={{ type: 'spring', damping: 18, stiffness: 280 }}
              onClick={onClose}
              className="absolute z-20 flex flex-col items-center justify-center w-16 h-16 rounded-full bg-gradient-to-tr from-gray-950 via-slate-900 to-red-600 text-white shadow-2xl ring-4 ring-white/90 hover:scale-105 active:scale-95 transition-transform"
              title="বন্ধ করুন"
              aria-label="বন্ধ করুন"
            >
              <div className="relative flex items-center justify-center">
                <Layers className="w-6 h-6 text-amber-300" />
                <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
                </span>
              </div>
              <span className="text-[8.5px] font-bold text-amber-200 mt-0.5 tracking-tight leading-none">
                মডিউল
              </span>
            </motion.button>

            {/* Circular Orbiting Module Icons */}
            {MODULES.map((mod, index) => {
              // Evenly spaced angles starting from top (-90 degrees)
              const angleDeg = index * (360 / total) - 90;
              const angleRad = angleDeg * (Math.PI / 180);
              const x = Math.round(Math.cos(angleRad) * radius);
              const y = Math.round(Math.sin(angleRad) * radius);

              const isActive = mod.id === activeModule;
              const Icon = mod.icon;

              return (
                <motion.button
                  key={mod.id}
                  id={`radial-module-btn-${mod.id}`}
                  initial={{ opacity: 0, x: 0, y: 0, scale: 0 }}
                  animate={{ opacity: 1, x, y, scale: 1 }}
                  exit={{ opacity: 0, x: 0, y: 0, scale: 0 }}
                  transition={{
                    delay: index * 0.025 + 0.05,
                    type: 'spring',
                    stiffness: 280,
                    damping: 22,
                  }}
                  onClick={() => {
                    onSelectModule(mod.id);
                    onClose();
                  }}
                  className={`group absolute z-30 flex flex-col items-center justify-center transition-transform active:scale-90 ${
                    isActive ? 'scale-105' : 'hover:scale-110'
                  }`}
                  aria-label={mod.name}
                  title={`${mod.name} - ${mod.sub}`}
                >
                  {/* Round Circular Icon */}
                  <div
                    className={`relative flex items-center justify-center w-[54px] h-[54px] rounded-full bg-gradient-to-tr ${mod.gradient} text-white shadow-lg ring-2 ring-white transition-all group-hover:shadow-xl ${
                      isActive ? `ring-4 ${mod.activeRing} shadow-md` : ''
                    }`}
                  >
                    <Icon className="w-6 h-6 stroke-[2.2] drop-shadow-xs" />

                    {/* Active Indicator Dot */}
                    {isActive && (
                      <span className="absolute -top-1 -right-1 bg-emerald-500 border-2 border-white rounded-full w-3.5 h-3.5 flex items-center justify-center shadow-xs" />
                    )}
                  </div>

                  {/* Name Pill Badge */}
                  <span
                    className={`mt-1 px-2 py-0.5 rounded-full text-[10px] font-bold shadow-md backdrop-blur-md leading-tight transition-colors ${
                      isActive
                        ? 'bg-white text-gray-900 ring-2 ring-amber-400 font-extrabold'
                        : 'bg-white/95 text-gray-800 group-hover:bg-white'
                    }`}
                  >
                    {mod.name}
                  </span>
                </motion.button>
              );
            })}

            {/* Bottom Floating Close Button */}
            <motion.button
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ delay: 0.2 }}
              onClick={onClose}
              className="absolute bottom-10 px-5 py-2 bg-white/20 hover:bg-white/30 border border-white/30 rounded-full text-white backdrop-blur-md text-xs font-semibold flex items-center gap-1.5 shadow-lg active:scale-95 transition-all"
            >
              <X className="w-4 h-4" />
              <span>বন্ধ করুন</span>
            </motion.button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

